<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Freeport</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/freeport/app-full-featured.js'); ?>
  </head>
  <body class="antialiased">
    <div id="root"></div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravel-sanctum-api\resources\views\app.blade.php ENDPATH**/ ?>