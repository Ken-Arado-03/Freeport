<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freeport - Freelancing Marketplace</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  </head>
  <body>
    <h1>API is ready. Build your frontend here.</h1>
    <p>Your Laravel Sanctum API is fully functional at <code>/api</code></p>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravel-sanctum-api\resources\views/app.blade.php ENDPATH**/ ?>