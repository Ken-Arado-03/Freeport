
  # Freelancing Marketplace UI Kit

  This is a code bundle for Freelancing Marketplace UI Kit. The original project is available at https://www.figma.com/design/sBzivRnx4mpb1icFjXGCMK/Freelancing-Marketplace-UI-Kit.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  